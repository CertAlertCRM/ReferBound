"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { STATUSES, STATUS_LABELS, nextStatusFor, statusLabel, isFullTrack } from "@/lib/config";
import { formatPhoneInput } from "@/lib/format";
import { StatusBadge, AtRiskBadge, StatusProgress, TopNav } from "./components";
import { IconPlus, IconArrowRight, IconChevronDown, IconChevronUp, IconDownload, IconCheck, IconUsers, IconZap, IconFile, IconX, IconCalendar, IconMail } from "./icons";
import { BackfillButton } from "./backfill";
import { LeadPrefillBox } from "./lead-prefill";
import { InstallPrompt } from "./install-prompt";
import { EmptyStart } from "./empty-start";
import { useUI } from "./ui";

type Referral = {
  id: string;
  client_name: string;
  client_phone: string | null;
  closing_date: string | null;
  status: string;
  source: string;
  created_at: string;
  updated_at: string | null;
  premium: number | null;
  backfilled?: boolean;
  client_dob: string | null;
  property_address: string | null;
  partners: { name: string; partner_type?: string } | null;
  documents: { id: string; kind: string }[];
};

type Partner = { id: string; name: string };

type ActivityItem = {
  id: number;
  referral_id: string;
  event_type: string;
  detail: string | null;
  actor: string;
  created_at: string;
  client_name: string | null;
};

function daysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const d = new Date(dateStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - now.getTime()) / 86400000);
}

function atRisk(r: Referral): boolean {
  const days = daysUntil(r.closing_date);
  return (
    days !== null &&
    days <= 7 &&
    days >= -1 &&
    !["bound", "docs_delivered", "lost"].includes(r.status)
  );
}

// A lender deal runs the whole pipeline; a realtor's referral stops at covered.
function nextStatus(r: { status: string; partners: { partner_type?: string } | null }): string | null {
  return nextStatusFor(r.status, r.partners?.partner_type);
}

export default function Dashboard() {
  const { toast, confirm, prompt } = useUI();
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [feed, setFeed] = useState<ActivityItem[]>([]);
  const [feedOpen, setFeedOpen] = useState(false);
  const [profileName, setProfileName] = useState<string | null>(null);
  const [headshotUrl, setHeadshotUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [inboxPending, setInboxPending] = useState(0);

  const formOpenedAt = useRef<number>(0);
  const EMPTY_LEAD = {
    client_name: "",
    coborrower_name: "",
    client_phone: "",
    client_email: "",
    client_dob: "",
    property_address: "",
    partner_id: "",
    closing_date: "",
    notes: "",
  };
  const [form, setForm] = useState({ ...EMPTY_LEAD });
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  async function load() {
    const [rRes, pRes, profRes, aRes] = await Promise.all([
      fetch("/api/referrals"),
      fetch("/api/partners"),
      fetch("/api/profile"),
      fetch("/api/activity"),
    ]);
    if (rRes.ok) setReferrals((await rRes.json()).referrals ?? []);
    if (pRes.ok) setPartners((await pRes.json()).partners ?? []);
    if (aRes.ok) setFeed((await aRes.json()).activity ?? []);
    if (profRes.ok) {
      const { profile, headshotUrl } = await profRes.json();
      setProfileName(profile?.display_name ?? null);
      setHeadshotUrl(headshotUrl ?? null);
    }
    setLoading(false);

    // Held forwards, fetched after the page has already painted — a queue
    // that's empty most days shouldn't slow the dashboard down.
    fetch("/api/inbox")
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => setInboxPending((j?.emails ?? []).filter((e: any) => e.status === "pending").length))
      .catch(() => {});
  }
  useEffect(() => {
    load();
  }, []);

  function openAdd() {
    formOpenedAt.current = Date.now();
    setShowAdd(true);
  }

  async function saveLead(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const log_seconds = Math.round((Date.now() - formOpenedAt.current) / 100) / 10;
    const res = await fetch("/api/referrals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, log_seconds }),
    });
    if (!res.ok) {
      setSaving(false);
      toast((await res.json()).error ?? "Failed to save", "error");
      return;
    }
    const { referral } = await res.json();
    // Attach the prefill source doc (the 1003 the LO emailed) automatically.
    if (pendingFile && referral?.id) {
      const fd = new FormData();
      fd.append("file", pendingFile);
      fd.append("kind", "loan_1003");
      await fetch(`/api/referrals/${referral.id}/docs`, { method: "POST", body: fd }).catch(() => {});
    }
    setSaving(false);
    setForm({ ...EMPTY_LEAD, partner_id: form.partner_id });
    setPendingFile(null);
    setShowAdd(false);
    load();
  }

  async function advance(r: Referral) {
    const ns = nextStatus(r);
    if (!ns) return;
    if (ns === "docs_delivered" && (r.documents?.length ?? 0) === 0) {
      const ok = await confirm(
        "No documents are uploaded yet, but this sends the partner their one “bound + documents ready” email. Open the deal to upload the EOI/RCE first, or continue anyway?"
      );
      if (!ok) return;
    }
    setBusyId(r.id);
    await fetch(`/api/referrals/${r.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: ns }),
    });
    setBusyId(null);
    load();
  }

  // Mark a deal "Not written" right from the list — no email goes to the
  // partner (that conversation deserves a personal touch); it just moves to
  // the Not written section and the portal shows it honestly.
  async function markLost(r: Referral) {
    const reason = await prompt({
      title: `Mark ${r.client_name} as “Not written”?`,
      body: "No email goes to your partner — that conversation deserves a personal touch.",
      placeholder: "Optional reason (shows in your records)",
      confirmLabel: "Mark not written",
    });
    if (reason === null) return;
    setBusyId(r.id);
    await fetch(`/api/referrals/${r.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "lost", lost_reason: reason.trim() || null }),
    });
    setBusyId(null);
    load();
  }

  const groups = useMemo(() => {
    const risk = referrals.filter(atRisk);
    const active = referrals.filter(
      (r) => !atRisk(r) && !["bound", "docs_delivered", "lost"].includes(r.status)
    );
    const done = referrals.filter((r) => ["bound", "docs_delivered"].includes(r.status));
    const lost = referrals.filter((r) => r.status === "lost");
    return { risk, active, done, lost };
  }, [referrals]);

  const inProgress = groups.risk.length + groups.active.length;

  return (
    <>
      <TopNav active="referrals" />
      <main className="max-w-3xl xl:max-w-6xl mx-auto p-4 sm:p-6">
        <div className="xl:grid xl:grid-cols-[minmax(0,1fr)_340px] xl:gap-6 xl:items-start">
        <div className="space-y-6 min-w-0">
        <InstallPrompt />
        {/* No partners yet — the cold start. Give them something to hand a
            lender instead of an empty board and a description. */}
        {!loading && partners.length === 0 && (
          <EmptyStart agentFirstName={profileName?.split(" ")[0]} />
        )}
        {/* Greeting */}
        {(profileName || headshotUrl) && (
          <div className="flex items-center gap-4 sm:gap-5">
            {headshotUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={headshotUrl}
                alt=""
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-[3px] border-white shadow-lift ring-1 ring-slate-200"
              />
            ) : (
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-brand text-white flex items-center justify-center text-4xl font-bold border-[3px] border-white shadow-lift ring-1 ring-slate-200">
                {(profileName || "?").charAt(0).toUpperCase()}
              </div>
            )}
            <div>
              <p className="text-3xl sm:text-4xl font-bold tracking-tight leading-tight">
                Welcome back{profileName ? `, ${profileName.split(" ")[0]}` : ""}
              </p>
              <p className="text-sm sm:text-base text-ink-secondary mt-1">Here&apos;s where your referrals stand.</p>
            </div>
          </div>
        )}

        {/* Stat tiles */}
        <div className="flex items-start justify-between gap-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 flex-1 stagger">
            {[
              { v: String(inProgress), l: "In progress" },
              {
                v: String(groups.risk.length),
                l: "Closing soon",
                alert: groups.risk.length > 0,
                href: "/closing",
                hint: "see the week",
              },
              { v: String(groups.done.length), l: "Bound" },
              {
                // Live business only — imported history has its own ledger on
                // the Stats page, so this number never flatters itself.
                v: (() => {
                  const p = referrals
                    .filter((r) => ["bound", "docs_delivered"].includes(r.status) && !r.backfilled)
                    .reduce((a, r) => a + (r.premium ?? 0), 0);
                  return p > 0 ? `$${Math.round(p).toLocaleString()}` : "$0";
                })(),
                l: "Premium sourced",
                hint: referrals.some((r) => r.backfilled) ? "live business only" : undefined,
              },
            ].map((t: any) => {
              const inner = (
                <>
                  <p className={`tabnum text-xl font-semibold tracking-tight leading-6 ${t.alert ? "text-red-600" : ""}`}>
                    {t.v}
                  </p>
                  <p className="text-[11px] text-ink-muted mt-0.5">{t.l}</p>
                  {t.hint && <p className="text-[10px] text-ink-muted">{t.hint}</p>}
                </>
              );
              const cls = `card card-hover px-4 py-3 block ${t.alert ? "border-red-200" : ""}`;
              return t.href ? (
                <Link key={t.l} href={t.href} className={cls}>
                  {inner}
                </Link>
              ) : (
                <div key={t.l} className={cls}>
                  {inner}
                </div>
              );
            })}
          </div>
          <div className="flex flex-col items-stretch gap-2 shrink-0">
            <button onClick={openAdd} className="btn-primary">
              <IconPlus size={15} /> Log lead
            </button>
            {partners.length > 0 && (
              <BackfillButton
                partners={partners}
                onDone={load}
                className="btn-ghost !py-1.5 text-xs justify-center"
                label={referrals.length === 0 ? "Build my book" : "Add several"}
              />
            )}
            {referrals.length > 0 && (
              <a
                href="/api/export?scope=new"
                className="btn-ghost !py-1.5 text-xs justify-center"
                title="Downloads only leads that haven't been exported before — no re-keying duplicates into your CRM"
              >
                <IconDownload size={13} /> Export new
              </a>
            )}
          </div>
        </div>

        {showAdd && (
          <form onSubmit={saveLead} className="card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">New referral</h2>
              <button type="button" className="text-sm text-ink-muted hover:text-ink" onClick={() => setShowAdd(false)}>
                Cancel
              </button>
            </div>
            <LeadPrefillBox
              onFile={setPendingFile}
              onFields={(f) =>
                setForm((prev) => {
                  const next = { ...prev };
                  for (const k of Object.keys(next) as (keyof typeof next)[]) {
                    if (k === "partner_id") continue;
                    if (f[k] && !next[k]) next[k] = k === "client_phone" ? formatPhoneInput(f[k]) : f[k];
                  }
                  return next;
                })
              }
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                className="input"
                placeholder="Client name *"
                value={form.client_name}
                onChange={(e) => setForm({ ...form, client_name: e.target.value })}
                required
              />
              <input
                className="input"
                placeholder="Co-borrower (optional)"
                value={form.coborrower_name}
                onChange={(e) => setForm({ ...form, coborrower_name: e.target.value })}
              />
              <select
                className="input"
                value={form.partner_id}
                onChange={(e) => setForm({ ...form, partner_id: e.target.value })}
                required
              >
                <option value="">Referred by… *</option>
                {partners.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
              <input
                className="input"
                type="tel"
                inputMode="tel"
                placeholder="Client phone (804-555-1234)"
                value={form.client_phone}
                onChange={(e) => setForm({ ...form, client_phone: formatPhoneInput(e.target.value) })}
              />
              <input
                className="input"
                type="email"
                placeholder="Client email"
                value={form.client_email}
                onChange={(e) => setForm({ ...form, client_email: e.target.value })}
              />
              <label className="block">
                <span className="section-label">Date of birth</span>
                <input
                  type="date"
                  className="input mt-1.5"
                  value={form.client_dob}
                  onChange={(e) => setForm({ ...form, client_dob: e.target.value })}
                />
              </label>
              <input
                className="input sm:col-span-2"
                placeholder="Property address (street, city, state, zip)"
                value={form.property_address}
                onChange={(e) => setForm({ ...form, property_address: e.target.value })}
              />
              <label className="block">
                <span className="section-label">Closing date</span>
                <input
                  type="date"
                  className="input mt-1.5"
                  value={form.closing_date}
                  onChange={(e) => setForm({ ...form, closing_date: e.target.value })}
                />
              </label>
              <label className="block">
                <span className="section-label">Notes</span>
                <input
                  className="input mt-1.5"
                  placeholder="Optional"
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                />
              </label>
            </div>
            <button className="btn-primary w-full" disabled={saving}>
              {saving ? "Saving…" : "Save lead"}
            </button>
            <p className="text-xs text-ink-muted text-center">Log time is measured automatically for the pilot.</p>
          </form>
        )}

        {loading ? (
          <div className="space-y-2.5">
            {[0, 1, 2].map((i) => (
              <div key={i} className="card p-4 animate-pulse">
                <div className="h-4 w-40 bg-slate-200 rounded" />
                <div className="h-3 w-64 bg-slate-100 rounded mt-2.5" />
                <div className="h-1.5 w-full bg-slate-100 rounded mt-3.5" />
              </div>
            ))}
          </div>
        ) : referrals.length === 0 ? (
          <GettingStarted profileDone={Boolean(profileName)} partnerDone={partners.length > 0} />
        ) : (
          <>
            {inboxPending > 0 && (
              <Link
                href="/inbox"
                className="card card-hover p-4 flex items-center gap-3 border-brand-200 bg-brand-light/40 block"
              >
                <IconMail size={16} className="text-brand shrink-0" />
                <span className="min-w-0">
                  <span className="text-sm font-semibold block">
                    {inboxPending} forwarded email{inboxPending === 1 ? "" : "s"} waiting on you
                  </span>
                  <span className="text-xs text-ink-secondary">
                    Details are already pulled out — one click turns each into a lead.
                  </span>
                </span>
                <IconArrowRight size={14} className="ml-auto text-ink-muted shrink-0" />
              </Link>
            )}
            <Section title="Closing soon — not bound" items={groups.risk} advance={advance} markLost={markLost} busyId={busyId} highlight />
            <Section title="Active" items={groups.active} advance={advance} markLost={markLost} busyId={busyId} />
            <Section title="Bound & delivered" items={groups.done} advance={advance} markLost={markLost} busyId={busyId} collapsible />
            <Section title="Not written" items={groups.lost} advance={advance} markLost={markLost} busyId={busyId} collapsible />
          </>
        )}
        </div>

        {/* Desktop rail — the margins earn their keep on wide screens */}
        <aside className="hidden xl:block space-y-4 sticky top-6">
          {groups.risk.length > 0 && (
            <div className="card p-5 border-red-200">
              <h3 className="section-label text-red-600 mb-2.5">Needs attention</h3>
              <ul className="space-y-2">
                {groups.risk.slice(0, 4).map((r) => (
                  <li key={r.id}>
                    <Link href={`/deal/${r.id}`} className="block group">
                      <p className="text-sm font-semibold group-hover:text-brand transition-colors">
                        {r.client_name}
                      </p>
                      <p className="text-[11px] text-red-600">
                        closes {r.closing_date} · {STATUS_LABELS[r.status] ?? r.status}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="card p-5">
            <h3 className="section-label mb-3">Latest activity</h3>
            {feed.length === 0 ? (
              <p className="text-sm text-ink-muted">
                Everything that happens — leads, status moves, emails, messages — shows up here.
              </p>
            ) : (
              <ul className="space-y-3">
                {feed.slice(0, feedOpen ? 16 : 5).map((a) => (
                  <li key={a.id} className="flex gap-2.5">
                    <span
                      className={`mt-[7px] w-2 h-2 rounded-full shrink-0 ${
                        a.actor === "partner"
                          ? "bg-brand"
                          : a.actor === "system"
                            ? "bg-amber-400"
                            : "bg-slate-300"
                      }`}
                    />
                    <div className="min-w-0">
                      <Link
                        href={`/deal/${a.referral_id}`}
                        className="text-[13px] text-ink-secondary hover:text-ink transition-colors line-clamp-2 block leading-snug"
                      >
                        {a.client_name && (
                          <span className="font-semibold text-ink">{a.client_name} — </span>
                        )}
                        {a.detail ?? a.event_type}
                      </Link>
                      <p className="text-[11px] text-ink-muted mt-0.5">{timeAgo(a.created_at)}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
            {feed.length > 5 && (
              <button
                type="button"
                className="link !text-xs mt-3.5"
                onClick={() => setFeedOpen(!feedOpen)}
              >
                {feedOpen ? (
                  <>
                    <IconChevronUp size={12} /> Show less
                  </>
                ) : (
                  <>
                    <IconChevronDown size={12} /> Show more ({Math.min(feed.length, 16) - 5})
                  </>
                )}
              </button>
            )}
          </div>

          <div className="card p-5">
            <h3 className="section-label mb-2">Quick actions</h3>
            <div className="-mx-2">
              {[
                { href: "/closing", icon: IconCalendar, label: "Closing week" },
                {
                  href: "/inbox",
                  icon: IconMail,
                  label: inboxPending > 0 ? `Email intake (${inboxPending} waiting)` : "Email intake",
                },
                { href: "/partners", icon: IconUsers, label: "Add or manage partners" },
                { href: "/stats", icon: IconZap, label: "Partner ROI & trends" },
                {
                  href: "/api/export?scope=new",
                  icon: IconDownload,
                  label: "Export new leads (CSV)",
                  title: "Only leads not previously exported",
                  plain: true,
                },
                { href: "/api/export?scope=all", icon: IconFile, label: "Export everything (CSV)", plain: true },
              ].map((x) =>
                x.plain ? (
                  <a
                    key={x.label}
                    href={x.href}
                    title={x.title}
                    className="flex items-center gap-2.5 px-2 py-2 rounded-lg text-sm font-medium text-ink-secondary hover:text-brand hover:bg-brand-light/50 transition-colors"
                  >
                    <x.icon size={15} className="text-ink-muted shrink-0" />
                    {x.label}
                    <IconArrowRight size={13} className="ml-auto text-ink-muted" />
                  </a>
                ) : (
                  <Link
                    key={x.label}
                    href={x.href}
                    className="flex items-center gap-2.5 px-2 py-2 rounded-lg text-sm font-medium text-ink-secondary hover:text-brand hover:bg-brand-light/50 transition-colors"
                  >
                    <x.icon size={15} className="text-ink-muted shrink-0" />
                    {x.label}
                    <IconArrowRight size={13} className="ml-auto text-ink-muted" />
                  </Link>
                )
              )}
            </div>
          </div>
        </aside>
        </div>
      </main>
    </>
  );
}

function timeAgo(iso: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.round(hrs / 24);
  return days === 1 ? "yesterday" : `${days}d ago`;
}

function GettingStarted({ profileDone, partnerDone }: { profileDone: boolean; partnerDone: boolean }) {
  const steps = [
    {
      done: profileDone,
      title: "Fill in your profile",
      body: "Your name, agency, and headshot appear on every partner portal — it's how partners see you.",
      href: "/profile",
      cta: "Open profile",
    },
    {
      done: partnerDone,
      title: "Add your best referral partner",
      body: "Start with the lender or realtor who sends you the most business. Takes thirty seconds.",
      href: "/partners",
      cta: "Add a partner",
    },
    {
      done: false,
      title: "Log the deals already in motion",
      body: "Add the two or three referrals you're working right now — before you share anything. Their first look at the portal should be alive, never empty.",
      href: "/",
      cta: "Log a lead",
    },
    {
      done: false,
      title: "Then send them their magic link",
      body: "Text or email it over — no login on their end. They'll see live status on every referral (yes, including when things sit — that's the point: partners assume worse in silence than they ever learn from the truth).",
      href: "/partners",
      cta: "Copy magic link",
    },
  ];
  const next = steps.findIndex((s) => !s.done);
  return (
    <div className="card p-6 sm:p-8">
      <h2 className="font-bold tracking-tight">Let&apos;s get your first partner live</h2>
      <p className="text-sm text-ink-secondary mt-1">
        Three steps, about five minutes — then every lead they send lands here on its own.
      </p>
      <ol className="mt-5 space-y-4">
        {steps.map((s, i) => (
          <li key={s.title} className="flex items-start gap-3.5">
            <span
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                s.done
                  ? "bg-emerald-50 text-emerald-600"
                  : i === next
                    ? "bg-brand text-white"
                    : "bg-slate-100 text-ink-muted"
              }`}
            >
              {s.done ? <IconCheck size={14} /> : i + 1}
            </span>
            <div className="min-w-0">
              <p className={`text-sm font-semibold ${s.done ? "text-ink-muted line-through" : ""}`}>{s.title}</p>
              {!s.done && <p className="text-xs text-ink-secondary mt-0.5 leading-relaxed">{s.body}</p>}
              {!s.done && i === next && (
                <Link href={s.href} className="btn-primary !py-1.5 text-xs inline-flex mt-2">
                  {s.cta} <IconArrowRight size={12} />
                </Link>
              )}
            </div>
          </li>
        ))}
      </ol>
      <p className="text-xs text-ink-muted mt-5">
        Prefer to start solo? You can also{" "}
        <button type="button" className="link !text-xs" onClick={() => window.scrollTo({ top: 0 })}>
          log a lead yourself
        </button>{" "}
        with the button above.
      </p>
      <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
        <p className="text-sm font-semibold">📱 Put ReferBound on your phone</p>
        <p className="text-xs text-ink-secondary mt-1">
          It installs like an app — no app store needed. <span className="font-medium text-ink">iPhone:</span>{" "}
          open referbound.com in Safari → Share → Add to Home Screen.{" "}
          <span className="font-medium text-ink">Android:</span> Chrome shows an Install button in
          the address bar.
        </p>
      </div>
    </div>
  );
}

function Section({
  title,
  items,
  advance,
  markLost,
  busyId,
  highlight,
  collapsible,
}: {
  title: string;
  items: Referral[];
  advance: (r: Referral) => void;
  markLost: (r: Referral) => void;
  busyId: string | null;
  highlight?: boolean;
  collapsible?: boolean;
}) {
  const [open, setOpen] = useState(!collapsible);
  if (items.length === 0) return null;
  if (collapsible && !open) {
    return (
      <section>
        <button
          onClick={() => setOpen(true)}
          className="w-full card px-4 py-3 flex items-center justify-between text-left hover:shadow-lift transition-shadow"
        >
          <span className="section-label">
            {title} · {items.length}
          </span>
          <span className="link">
            Show <IconChevronDown size={13} />
          </span>
        </button>
      </section>
    );
  }
  return (
    <section className="space-y-2.5">
      <h2 className={`section-label ${highlight ? "!text-red-600" : ""} flex items-center justify-between`}>
        <span>
          {title} · {items.length}
        </span>
        {collapsible && (
          <button onClick={() => setOpen(false)} className="link normal-case tracking-normal">
            Hide <IconChevronUp size={13} />
          </button>
        )}
      </h2>
      <div className="space-y-2.5">
        {items.map((r) => {
          const ns = nextStatus(r);
          const days = daysUntil(r.closing_date);
          return (
            <div
              key={r.id}
              className={`card card-hover p-4 ${highlight ? "border-red-200" : ""}`}
            >
              <div className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Link href={`/deal/${r.id}`} className="font-semibold hover:text-brand truncate">
                      {r.client_name}
                    </Link>
                    <StatusBadge status={r.status} partnerType={r.partners?.partner_type} />
                    {atRisk(r) && <AtRiskBadge />}
                    {r.source === "partner" && (
                      <span className="badge bg-brand-light text-brand-700">via portal</span>
                    )}
                    {!["bound", "docs_delivered", "lost"].includes(r.status) &&
                      (!r.client_dob || !r.property_address) && (
                        <span className="badge bg-amber-50 text-amber-700" title="Missing DOB or property address — open the deal to request or extract it">
                          missing info
                        </span>
                      )}
                  </div>
                  <p className="text-xs text-ink-muted mt-1">
                    {r.partners?.name ?? "—"}
                    {r.closing_date && (
                      <> · closes {r.closing_date}{days !== null && days >= 0 ? ` (${days}d)` : ""}</>
                    )}
                    {r.documents?.length > 0 && <> · {r.documents.length} doc{r.documents.length > 1 ? "s" : ""}</>}
                    {(() => {
                      // Quiet-deal nudge: the partner can see this sitting still.
                      if (["bound", "docs_delivered", "lost"].includes(r.status)) return null;
                      const ref = r.updated_at ?? r.created_at;
                      const quietDays = Math.floor((Date.now() - new Date(ref).getTime()) / 86400000);
                      return quietDays >= 4 ? (
                        <span className="text-amber-700 font-medium" title="No update in a while — your partner's portal shows the last-updated date. A one-tap touch log counts.">
                          {" "}· quiet {quietDays}d
                        </span>
                      ) : null;
                    })()}
                  </p>
                </div>
                {ns && r.status !== "lost" && (
                  <button
                    onClick={() => advance(r)}
                    disabled={busyId === r.id}
                    className="btn-ghost shrink-0 !px-3 !py-1.5 text-xs"
                    title={
                      ns === "quoted" || ns === "docs_delivered"
                        ? `Advance to ${STATUS_LABELS[ns]} — emails the partner`
                        : `Advance to ${STATUS_LABELS[ns]} — updates the portal silently`
                    }
                  >
                    {busyId === r.id ? "…" : (
                      <>
                        {STATUS_LABELS[ns]}
                        {(ns === "quoted" || ns === "docs_delivered") && <span aria-hidden> ✉</span>}{" "}
                        <IconArrowRight size={12} />
                      </>
                    )}
                  </button>
                )}
                {!["bound", "docs_delivered", "lost"].includes(r.status) && (
                  <button
                    onClick={() => markLost(r)}
                    disabled={busyId === r.id}
                    className="shrink-0 text-ink-muted hover:text-red-600 transition-colors px-1"
                    title="Mark as Not written — no email goes out; it moves to the Not written section"
                    aria-label={`Mark ${r.client_name} as not written`}
                  >
                    <IconX size={14} />
                  </button>
                )}
              </div>
              <div className="mt-3">
                <StatusProgress status={r.status} partnerType={r.partners?.partner_type} />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
