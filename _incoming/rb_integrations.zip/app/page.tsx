"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { STATUSES, STATUS_LABELS } from "@/lib/config";
import { formatPhoneInput } from "@/lib/format";
import { StatusBadge, AtRiskBadge, StatusProgress, TopNav } from "./components";
import { IconPlus, IconArrowRight, IconChevronDown, IconChevronUp, IconDownload } from "./icons";

type Referral = {
  id: string;
  client_name: string;
  client_phone: string | null;
  closing_date: string | null;
  status: string;
  source: string;
  created_at: string;
  premium: number | null;
  client_dob: string | null;
  property_address: string | null;
  partners: { name: string } | null;
  documents: { id: string; kind: string }[];
};

type Partner = { id: string; name: string };

function daysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const d = new Date(dateStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - now.getTime()) / 86400000);
}

function atRisk(r: Referral): boolean {
  const days = daysUntil(r.closing_date);
  return (
    days !== null &&
    days <= 7 &&
    days >= -1 &&
    !["bound", "docs_delivered", "lost"].includes(r.status)
  );
}

function nextStatus(status: string): string | null {
  const i = STATUSES.indexOf(status as any);
  if (i === -1 || i === STATUSES.length - 1) return null;
  return STATUSES[i + 1];
}

export default function Dashboard() {
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [profileName, setProfileName] = useState<string | null>(null);
  const [headshotUrl, setHeadshotUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const formOpenedAt = useRef<number>(0);
  const [form, setForm] = useState({
    client_name: "",
    client_phone: "",
    partner_id: "",
    closing_date: "",
    notes: "",
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    const [rRes, pRes, profRes] = await Promise.all([
      fetch("/api/referrals"),
      fetch("/api/partners"),
      fetch("/api/profile"),
    ]);
    if (rRes.ok) setReferrals((await rRes.json()).referrals ?? []);
    if (pRes.ok) setPartners((await pRes.json()).partners ?? []);
    if (profRes.ok) {
      const { profile, headshotUrl } = await profRes.json();
      setProfileName(profile?.display_name ?? null);
      setHeadshotUrl(headshotUrl ?? null);
    }
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  function openAdd() {
    formOpenedAt.current = Date.now();
    setShowAdd(true);
  }

  async function saveLead(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const log_seconds = Math.round((Date.now() - formOpenedAt.current) / 100) / 10;
    const res = await fetch("/api/referrals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, log_seconds }),
    });
    setSaving(false);
    if (res.ok) {
      setForm({ client_name: "", client_phone: "", partner_id: form.partner_id, closing_date: "", notes: "" });
      setShowAdd(false);
      load();
    } else {
      alert((await res.json()).error ?? "Failed to save");
    }
  }

  async function advance(r: Referral) {
    const ns = nextStatus(r.status);
    if (!ns) return;
    if (ns === "docs_delivered" && (r.documents?.length ?? 0) === 0) {
      const ok = confirm(
        "No documents are uploaded yet, but this sends the partner their one “bound + documents ready” email. Open the deal to upload the EOI/RCE first, or continue anyway?"
      );
      if (!ok) return;
    }
    setBusyId(r.id);
    await fetch(`/api/referrals/${r.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: ns }),
    });
    setBusyId(null);
    load();
  }

  const groups = useMemo(() => {
    const risk = referrals.filter(atRisk);
    const active = referrals.filter(
      (r) => !atRisk(r) && !["bound", "docs_delivered", "lost"].includes(r.status)
    );
    const done = referrals.filter((r) => ["bound", "docs_delivered"].includes(r.status));
    const lost = referrals.filter((r) => r.status === "lost");
    return { risk, active, done, lost };
  }, [referrals]);

  const inProgress = groups.risk.length + groups.active.length;

  return (
    <>
      <TopNav active="referrals" />
      <main className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
        {/* Greeting */}
        {(profileName || headshotUrl) && (
          <div className="flex items-center gap-3">
            {headshotUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={headshotUrl}
                alt=""
                className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-card"
              />
            ) : null}
            <div>
              <p className="text-lg font-bold tracking-tight leading-tight">
                Welcome back{profileName ? `, ${profileName.split(" ")[0]}` : ""}
              </p>
              <p className="text-xs text-ink-muted">Here&apos;s where your referrals stand.</p>
            </div>
          </div>
        )}

        {/* Stat tiles */}
        <div className="flex items-start justify-between gap-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 flex-1">
            {[
              { v: String(inProgress), l: "In progress" },
              { v: String(groups.risk.length), l: "Closing soon", alert: groups.risk.length > 0 },
              { v: String(groups.done.length), l: "Bound" },
              {
                v: (() => {
                  const p = referrals
                    .filter((r) => ["bound", "docs_delivered"].includes(r.status))
                    .reduce((a, r) => a + (r.premium ?? 0), 0);
                  return p > 0 ? `$${Math.round(p).toLocaleString()}` : "$0";
                })(),
                l: "Premium sourced",
              },
            ].map((t) => (
              <div key={t.l} className={`card px-4 py-3 ${t.alert ? "border-red-200" : ""}`}>
                <p className={`text-xl font-semibold tracking-tight leading-6 ${t.alert ? "text-red-600" : ""}`}>
                  {t.v}
                </p>
                <p className="text-[11px] text-ink-muted mt-0.5">{t.l}</p>
              </div>
            ))}
          </div>
          <div className="flex flex-col items-stretch gap-2 shrink-0">
            <button onClick={openAdd} className="btn-primary">
              <IconPlus size={15} /> Log lead
            </button>
            {referrals.length > 0 && (
              <a href="/api/export" className="btn-ghost !py-1.5 text-xs justify-center" title="Download all referrals as a CSV">
                <IconDownload size={13} /> Export CSV
              </a>
            )}
          </div>
        </div>

        {showAdd && (
          <form onSubmit={saveLead} className="card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">New referral</h2>
              <button type="button" className="text-sm text-ink-muted hover:text-ink" onClick={() => setShowAdd(false)}>
                Cancel
              </button>
            </div>
            <input
              className="input"
              placeholder="Client name *"
              value={form.client_name}
              onChange={(e) => setForm({ ...form, client_name: e.target.value })}
              autoFocus
              required
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <select
                className="input"
                value={form.partner_id}
                onChange={(e) => setForm({ ...form, partner_id: e.target.value })}
                required
              >
                <option value="">Referred by… *</option>
                {partners.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
              <input
                className="input"
                type="tel"
                inputMode="tel"
                placeholder="Client phone (804-555-1234)"
                value={form.client_phone}
                onChange={(e) => setForm({ ...form, client_phone: formatPhoneInput(e.target.value) })}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="block">
                <span className="section-label">Closing date</span>
                <input
                  type="date"
                  className="input mt-1.5"
                  value={form.closing_date}
                  onChange={(e) => setForm({ ...form, closing_date: e.target.value })}
                />
              </label>
              <label className="block">
                <span className="section-label">Notes</span>
                <input
                  className="input mt-1.5"
                  placeholder="Optional"
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                />
              </label>
            </div>
            <button className="btn-primary w-full" disabled={saving}>
              {saving ? "Saving…" : "Save lead"}
            </button>
            <p className="text-xs text-ink-muted text-center">Log time is measured automatically for the pilot.</p>
          </form>
        )}

        {loading ? (
          <div className="space-y-2.5">
            {[0, 1, 2].map((i) => (
              <div key={i} className="card p-4 animate-pulse">
                <div className="h-4 w-40 bg-slate-200 rounded" />
                <div className="h-3 w-64 bg-slate-100 rounded mt-2.5" />
                <div className="h-1.5 w-full bg-slate-100 rounded mt-3.5" />
              </div>
            ))}
          </div>
        ) : referrals.length === 0 ? (
          <div className="card p-10 text-center space-y-2">
            <p className="font-semibold">No referrals yet</p>
            <p className="text-sm text-ink-secondary">
              Add your partners first, then log your first lead — it takes seconds.
            </p>
            <Link href="/partners" className="btn-ghost inline-flex mt-2">
              Set up partners <IconArrowRight size={14} />
            </Link>
          </div>
        ) : (
          <>
            <Section title="Closing soon — not bound" items={groups.risk} advance={advance} busyId={busyId} highlight />
            <Section title="Active" items={groups.active} advance={advance} busyId={busyId} />
            <Section title="Bound & delivered" items={groups.done} advance={advance} busyId={busyId} collapsible />
            <Section title="Not written" items={groups.lost} advance={advance} busyId={busyId} collapsible />
          </>
        )}
      </main>
    </>
  );
}

function Section({
  title,
  items,
  advance,
  busyId,
  highlight,
  collapsible,
}: {
  title: string;
  items: Referral[];
  advance: (r: Referral) => void;
  busyId: string | null;
  highlight?: boolean;
  collapsible?: boolean;
}) {
  const [open, setOpen] = useState(!collapsible);
  if (items.length === 0) return null;
  if (collapsible && !open) {
    return (
      <section>
        <button
          onClick={() => setOpen(true)}
          className="w-full card px-4 py-3 flex items-center justify-between text-left hover:shadow-lift transition-shadow"
        >
          <span className="section-label">
            {title} · {items.length}
          </span>
          <span className="link">
            Show <IconChevronDown size={13} />
          </span>
        </button>
      </section>
    );
  }
  return (
    <section className="space-y-2.5">
      <h2 className={`section-label ${highlight ? "!text-red-600" : ""} flex items-center justify-between`}>
        <span>
          {title} · {items.length}
        </span>
        {collapsible && (
          <button onClick={() => setOpen(false)} className="link normal-case tracking-normal">
            Hide <IconChevronUp size={13} />
          </button>
        )}
      </h2>
      <div className="space-y-2.5">
        {items.map((r) => {
          const ns = nextStatus(r.status);
          const days = daysUntil(r.closing_date);
          return (
            <div
              key={r.id}
              className={`card p-4 hover:shadow-lift transition-shadow ${highlight ? "border-red-200" : ""}`}
            >
              <div className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Link href={`/deal/${r.id}`} className="font-semibold hover:text-brand truncate">
                      {r.client_name}
                    </Link>
                    <StatusBadge status={r.status} />
                    {atRisk(r) && <AtRiskBadge />}
                    {r.source === "partner" && (
                      <span className="badge bg-brand-light text-brand-700">via portal</span>
                    )}
                    {!["bound", "docs_delivered", "lost"].includes(r.status) &&
                      (!r.client_dob || !r.property_address) && (
                        <span className="badge bg-amber-50 text-amber-700" title="Missing DOB or property address — open the deal to request or extract it">
                          missing info
                        </span>
                      )}
                  </div>
                  <p className="text-xs text-ink-muted mt-1">
                    {r.partners?.name ?? "—"}
                    {r.closing_date && (
                      <> · closes {r.closing_date}{days !== null && days >= 0 ? ` (${days}d)` : ""}</>
                    )}
                    {r.documents?.length > 0 && <> · {r.documents.length} doc{r.documents.length > 1 ? "s" : ""}</>}
                  </p>
                </div>
                {ns && r.status !== "lost" && (
                  <button
                    onClick={() => advance(r)}
                    disabled={busyId === r.id}
                    className="btn-ghost shrink-0 !px-3 !py-1.5 text-xs"
                    title={`Advance to ${STATUS_LABELS[ns]}`}
                  >
                    {busyId === r.id ? "…" : (
                      <>
                        {STATUS_LABELS[ns]} <IconArrowRight size={12} />
                      </>
                    )}
                  </button>
                )}
              </div>
              <div className="mt-3">
                <StatusProgress status={r.status} />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
